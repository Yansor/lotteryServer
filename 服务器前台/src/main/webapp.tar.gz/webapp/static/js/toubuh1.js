var headRight = document.getElementById('header-right');
if(document.documentElement.clientWidth<800){
	headRight.style.display='none';
}